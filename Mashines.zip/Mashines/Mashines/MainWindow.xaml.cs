﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mashines
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private object onEnterFrame;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_KeyDown(object sender, KeyEventArgs e)
        {
            
  
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
            var speed = 7;
           
            var piOver180 = Math.PI / 180;
            onEnterFrame = function(){
                //If the left or right keys are down, rotate the wheels
                if (Key.isDown(Key.LEFT))
                {
                    image.leftwheel._rotation = Math.Min(24, Math.max(-24, car.leftwheel._rotation - 5));
                    car.rightwheel._rotation = Math.min(24, Math.max(-24, car.rightwheel._rotation - 5));
                }
                if (Key.isDown(Key.RIGHT))
                {
                    car.leftwheel._rotation = Math.min(24, Math.max(-24, car.leftwheel._rotation + 4));
                    car.rightwheel._rotation = Math.min(24, Math.max(-24, car.rightwheel._rotation + 4));
                }
                //check if the up or down keys are pressed
                if (Key.isDown(Key.UP) || Key.isDown(Key.DOWN))
                {
                    //if the up key is down, the car moves forward
                    if (Key.isDown(Key.UP))
                    {
                        carDirection = 1;
                        //otherwise move the car backwards
                    }
                    else { carDirection = -1; }
                    //default turning to false
                    turning = 0;
                    //if the left or right keys are pressed, set turning to true and rotate the car
                    if (Key.isDown(Key.LEFT))
                    {
                        turning = 1;
                        car._rotation -= 5 * carDirection;
                    }
                    else if (Key.isDown(Key.RIGHT))
                    {
                        turning = 1;
                        car._rotation += 5 * carDirection;
                    }
                    //if the car isn't turning, reset the rotation of the tires
                    if (!turning)
                    {
                        car.leftwheel._rotation = 0;
                        car.rightwheel._rotation = 0;
                    }
                    //move the car. The y coordinate plane is flipped in flash, so we use - instead of +
                    car._x += Math.sin(car._rotation * piOver180) * speed * carDirection;
                    car._y -= Math.cos(car._rotation * piOver180) * (speed) * carDirection;
                }
            }
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                rotateObject.Angle = 30;
            }
            if (e.Key == Key.S)
            {
                rotateObject.Angle = 30;
                rotateObject.CenterX = 50;
            }

        }
    }
}
